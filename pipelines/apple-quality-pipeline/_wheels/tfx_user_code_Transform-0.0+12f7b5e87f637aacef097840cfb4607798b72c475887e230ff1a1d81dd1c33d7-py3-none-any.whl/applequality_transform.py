import tensorflow as tf

LABEL_KEY = "Quality"
FEATURE_KEY = ['Acidity', 'Crunchiness', 'Juiciness', 'Ripeness', 'Size', 'Sweetness', 'Weight']

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    outputs = {}

    for feature_name in FEATURE_KEY:
        outputs[transformed_name(feature_name)] = tf.cast(inputs[feature_name], tf.float64)
    
    outputs[transformed_name('Quality')] = tf.cast(inputs['Quality'], tf.int64)
    
    # Mengubah nilai-nilai pada kolom 'Quality' menjadi 0 dan 1
    #outputs[transformed_name(LABEL_KEY)] = tf.where(tf.equal(inputs[LABEL_KEY], 'bad'), 0, 1)
    
    return outputs
