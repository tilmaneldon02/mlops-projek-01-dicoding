import tensorflow as tf

LABEL_KEY = "Quality"
FEATURE_KEY = "Acidity"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    for key in inputs.keys():
        if key != 'A_id':
            outputs[key] = inputs[key]
        
    outputs = {}

    # Mengubah kolom 'Acidity' menjadi FLOAT
    outputs[transform_name(FEATURE_KEY)] = tft.decode_csv(inputs[FEATURE_KEY], tf.float32)
    
    # Mengubah nilai-nilai pada kolom 'Quality' menjadi 0 dan 1
    outputs[transform_name(LABEL_KEY)] = tf.where(tf.equal(inputs[LABEL_KEY], 'bad'), 0, 1)
    
    return outputs
