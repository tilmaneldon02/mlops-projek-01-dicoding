import tensorflow as tf

LABEL_KEY = "Quality"
FEATURE_KEY = ['Acidity', 'Crunchiness', 'Juiciness', 'Ripeness', 'Size', 'Sweetness', 'Weight']

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    outputs = {}

    outputs[transformed_name('Acidity')] = tf.cast(inputs[feature_name], 'float')
    
    # Convert 'Quality' from 'good'/'bad' to 1/0
    quality_values = tf.where(tf.equal(inputs[LABEL_KEY], 'good'), 1, 0)
    outputs[transformed_name(LABEL_KEY)] = tf.cast(quality_values, tf.int64)
    
    return outputs
