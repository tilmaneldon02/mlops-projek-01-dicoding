import tensorflow as tf

LABEL_KEY = "Quality"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(LABEL_KEY)] = tf.cast(tf.where(inputs[LABEL_KEY] == "good", 1, 0), tf.int64)

    return outputs
    
