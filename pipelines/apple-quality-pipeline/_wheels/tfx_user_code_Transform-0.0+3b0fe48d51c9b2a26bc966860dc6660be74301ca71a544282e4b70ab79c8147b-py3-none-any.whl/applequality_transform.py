import tensorflow as tf

LABEL_KEY = "Quality"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}

    # Convert SparseTensor to dense tensor
    dense_labels = tf.sparse.to_dense(inputs[LABEL_KEY], default_value="")
    
    # Transform the label using TensorFlow operations
    is_good = tf.strings.regex_full_match(dense_labels, "good")
    outputs[transformed_name(LABEL_KEY)] = tf.reshape(tf.cast(is_good, tf.int64), [-1])

    return outputs
    
