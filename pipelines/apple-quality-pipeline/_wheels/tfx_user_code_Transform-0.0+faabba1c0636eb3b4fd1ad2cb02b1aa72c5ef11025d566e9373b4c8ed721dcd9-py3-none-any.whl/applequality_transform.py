import tensorflow as tf

LABEL_KEY = "Quality"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    # Ensure the output dtype is int64
    outputs[transformed_name(LABEL_KEY)] = inputs[LABEL_KEY].apply(lambda x: 1 if x == "good" else 0)

    return outputs
    
